<?php $bodyClass = 'with-nav-bottom';?>
<?php include '../../common/view/m.header.html.php';?>
<div class="text-center">
  <p><span class="text-muted"><?php echo $lang->product->createInPC;?></span></p>
</div>
